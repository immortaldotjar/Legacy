import dotenv from "dotenv";
dotenv.config();

import app from "./app.js";

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log("Gemini configured:", Boolean(process.env.GEMINI_API_KEY));
    console.log("HuggingFace configured:", Boolean(process.env.HF_TOKEN));
});