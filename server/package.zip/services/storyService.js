import { GoogleGenAI } from "@google/genai";
import { generateStoryImages } from "./imageService.js";

const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
});

function buildFallbackStory(answers) {
    const chapters = [
        {
            title: "The Spark",
            content: `In the beginning, ${answers?.passion || "a quiet passion"} became the force that shaped every step forward. It was not a grand declaration, but a steady flame that kept calling the heart back to purpose.`,
            mood: "Hopeful",
        },
        {
            title: "The Beginning",
            content: `The journey started when ${answers?.beginning || "the first brave step"} opened a path that felt uncertain but deeply meaningful. Every memory carried the feeling that something important was beginning to unfold.`,
            mood: "Reflective",
        },
        {
            title: "The Storm",
            content: `Challenges arrived in the form of ${answers?.challenge || "difficult moments"}, testing patience, confidence, and belief. Yet each obstacle became a teacher, shaping resilience instead of breaking spirit.`,
            mood: "Tense",
        },
        {
            title: "The Fire",
            content: `What kept the journey alive was ${answers?.motivation || "a personal reason that never faded"}. Even in uncertainty, that deeper purpose gave the next step enough strength to arrive.`,
            mood: "Determined",
        },
        {
            title: "The Victory",
            content: `The achievement of ${answers?.achievement || "a meaningful milestone"} became a quiet celebration of perseverance. It was proof that persistence had turned effort into something lasting.`,
            mood: "Triumphant",
        },
        {
            title: "The Future",
            content: `Looking ahead, ${answers?.future || "the future feels full of possibility"}. The path ahead is still unfolding, but it now carries the confidence of someone who has already learned how to keep going.`,
            mood: "Inspirational",
        },
    ];

    return {
        title: "A Legacy in the Making",
        tagline: "A story shaped by courage, memory, and purpose.",
        openingQuote:
            "The most meaningful journeys are rarely planned; they are lived with heart.",
        chapters,
        ending:
            "What began as a single spark became a life defined by growth, resilience, and the courage to continue.",
    };
}

async function generateWithGemini(answers) {

    const prompt = `
You are an award-winning documentary writer.

Transform the interview below into a cinematic documentary.

Interview:

${JSON.stringify(answers, null, 2)}

Return ONLY valid JSON.

{
  "title":"",
  "tagline":"",
  "openingQuote":"",
  "chapters":[
    {
      "title":"",
      "content":"",
      "mood":""
    }
  ],
  "ending":""
}

Rules:

- Exactly 6 chapters
- Each chapter should contain 120-180 words
- Every chapter title must be unique
- Make it emotional and cinematic
- Write like a Netflix documentary
- Use vivid storytelling
- No markdown
- No explanations
- JSON only
`;

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
    });

    const text = response.text.trim();

    // Gemini sometimes wraps JSON
    const clean = text
        .replace(/```json/g, "")
        .replace(/```/g, "")
        .trim();

    return JSON.parse(clean);
}

export async function generateStory(req, res) {

    try {

        const answers = req.body;

        let story;

        try {

            story = await generateWithGemini(answers);

        } catch (err) {

            console.warn("Gemini failed. Using fallback story.");

            story = buildFallbackStory(answers);

        }

        console.log("Generating images...");

        const images = await generateStoryImages(story.chapters);

        story.images = images;

        console.log("Story completed.");

        return res.json(story);

    } catch (err) {

        console.error(err);

        return res.status(500).json({
            error: err.message,
        });

    }

}