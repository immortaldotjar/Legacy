import streamifier from "streamifier";
import cloudinary from "./cloudinary.js";

const WORKER_URL = process.env.CF_WORKER_URL;
const API_KEY = process.env.CF_API_KEY;

const ART_STYLE = `
Award-winning illustrated concept art.
Modern editorial illustration.
Bold clean outlines.
Painterly brush strokes.
Soft textured shading.
Rich cinematic lighting.
Golden hour.
Highly detailed environment.
Film still composition.
Masterpiece quality.

Anime inspired.
Portrait orientation.
NOT photorealistic.
NOT CGI.
NOT 3D.
NOT text.
NOT watermark.
`.trim();

function buildPrompt(chapter) {
    return `
${ART_STYLE}

Title:
${chapter.title}

Scene:
${chapter.content}

Mood:
${chapter.mood}

Create ONE cinematic illustration.

Requirements:
- One main character
- Dynamic camera angle
- Emotional storytelling
- Rich environment
- Beautiful color grading
- Portrait (9:16)
`.trim();
}

function uploadBuffer(buffer, fileName) {
    return new Promise((resolve, reject) => {
        const stream = cloudinary.uploader.upload_stream(
            {
                folder: "legacy",
                public_id: fileName,
                overwrite: true,
            },
            (err, result) => {
                if (err) return reject(err);
                resolve(result.secure_url);
            }
        );

        streamifier.createReadStream(buffer).pipe(stream);
    });
}

export async function generateImage(chapter) {
    try {
        const prompt = buildPrompt(chapter);

        const response = await fetch(WORKER_URL, {
            method: "POST",
            headers: {
                Authorization: `Bearer ${API_KEY}`,
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                prompt,
            }),
        });

        if (!response.ok) {
            const error = await response.text();
            throw new Error(error);
        }

        // Cloudflare returns image binary
        const arrayBuffer = await response.arrayBuffer();

        const buffer = Buffer.from(arrayBuffer);

        const url = await uploadBuffer(
            buffer,
            `chapter-${Date.now()}`
        );

        return url;

    } catch (err) {
        console.error("Image Generation Error:", err.message);
        return null;
    }
}

export async function generateStoryImages(chapters) {

    return await Promise.all(
        chapters.map(generateImage)
    );

}