export default function QuestionCard({
    question,
    value,
    updateAnswer,
}) {
    const chapter = typeof question?.chapter === "string" ? question.chapter : "";
    const prompt = typeof question?.question === "string" ? question.question : "";
    const placeholder = typeof question?.placeholder === "string" ? question.placeholder : "";
    const answerValue = typeof value === "string" ? value : "";

    return (
        <div>
             <p>{chapter}</p>

            <h2>{prompt}</h2>

            <textarea
                value={answerValue}
                onChange={(e) => updateAnswer?.(e.target.value)}
                placeholder={placeholder}
            />
        </div>
    );
}