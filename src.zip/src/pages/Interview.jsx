import InterviewHeader from "../components/Interview/InterviewHeader";
import ProgressBar from "../components/Interview/ProgressBar";
import QuestionCard from "../components/Interview/QuestionCard";
import NavBtn from "../components/Interview/NavBtn"
import AnimatedQuestion from "../components/Interview/AnimatedQuestions";

import useInterview from "../hooks/useInterview";

export default function Interview() {
  const {
    current,
    total,
    question,
    answers,
    updateAnswer,
    next,
    previous,
  } = useInterview();

  return (
    <main className="min-h-screen bg-zinc-950 text-white">

      <div className="mx-auto max-w-4xl px-6 py-20">

        <InterviewHeader />

        <ProgressBar
          current={current}
          total={total}
        />

        <AnimatedQuestion current={current}>

          <QuestionCard
            question={question}
            value={answers[question.key]}
            updateAnswer={updateAnswer}
          />

        </AnimatedQuestion>

        <NavBtn
          current={current}
          total={total}
          previous={previous}
          next={next}
        />

      </div>

    </main>
  );
}