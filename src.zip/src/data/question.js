export const questions = [
  {
    id: 1,
    key: "passion",
    chapter: "The Spark",
    question: "What is the one thing you could spend hours doing without getting tired?",
    placeholder: "Coding, football, music, photography..."
  },
  {
    id: 2,
    key: "beginning",
    chapter: "The Beginning",
    question: "When did this journey begin?",
    placeholder: "Tell us about the moment everything started..."
  },
  {
    id: 3,
    key: "challenge",
    chapter: "The Storm",
    question: "Tell us about a moment when you almost gave up.",
    placeholder: "What happened?"
  },
  {
    id: 4,
    key: "motivation",
    chapter: "The Turning Point",
    question: "What kept you moving forward?",
    placeholder: "A person, dream, belief or memory..."
  },
  {
    id: 5,
    key: "achievement",
    chapter: "The Victory",
    question: "What achievement makes you smile the most?",
    placeholder: "A project, competition, milestone..."
  },
  {
    id: 6,
    key: "future",
    chapter: "The Horizon",
    question: "Where do you hope this journey takes you?",
    placeholder: "Describe your biggest dream..."
  }
];